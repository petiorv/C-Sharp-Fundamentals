﻿public abstract class Race
{
    
}
