﻿public class Citizen : IControlable, IBirthable, IBuyer
{
    private const int increaseFood = 10;
    private int food = 0;

    public Citizen(string name, int age, string id)
    {
        this.Name = name;
        this.Age = age;
        this.Id = id;
    }

    public Citizen(string name, int age, string id, string birhtdate)
    {
        this.Name = name;
        this.Age = age;
        this.Id = id;
        this.Birthdate = birhtdate;
    }

    public string Name { get; set; }
    public int Age { get; set; }
    public string Id { get; set; }
    public string Birthdate { get; set; }

    public int Food
    {
        get { return this.food; }
        private set { this.food = value; }
    }

    public void ByeFood()
    {
        this.Food += increaseFood;
    }
}
