﻿
class Puppy : Dog
{
    public void Weep()
    {
        System.Console.WriteLine("weeping");
    }
}

