﻿using NUnit.Framework;
using System;
using System.Collections.Generic;

[TestFixture]
public class DatabaseTests
{

    private const string ErrorMessageForDifferentCount = "Database have {0}count different than input collection";

    [Test]
    public void DatabaseCapacityIsSixteen()
    {
        Database db = new Database(new List<int>() { 1, 2, 3 });

        Assert.AreEqual(16, db.Capacity, "Capacity must be 16");
    }

    [Test]
    [TestCase(0)]
    [TestCase(1)]
    [TestCase(6)]
    [TestCase(16)]
    public void DatebaseContructorWorkWithValidNumberOfElements(int count)
    {
        //Arrange
        List<int> list = new List<int>();
        for (int i = 0; i < count; i++)
        {
            list.Add(i);
        }

        //Act
        Database db = new Database(list);

        //Assert
        Assert.AreEqual(count, db.Count, string.Format(ErrorMessageForDifferentCount, count));
    }

    [Test]
    [TestCase(17)]
    public void DatabaseCtorWorkWithInvalidNumberofElements(int count)
    {
        List<int> list = new List<int>();
        for (int i = 0; i < count; i++)
        {
            list.Add(i);
        }

        Assert.Throws<InvalidOperationException>(() => new Database(list), "Database cannot be with more than 16");
    }

    [Test]
    public void DatabaseCtorWithNullValue()
    {
        Assert.Throws<ArgumentNullException>(() => new Database(null), "Database cannot be initilized with null");
    }


    [Test]
    public void DatabaseElementsReturnsCollection()
    {
        Database db = new Database(new List<int>() { 1, 2, 3 });

        CollectionAssert.AreEqual(new int[] { 1, 2, 3 }, db.Elements);
        Assert.AreEqual(3, db.Count, string.Format(ErrorMessageForDifferentCount, 3));

    }

    [Test]
    public void AddElementToDatabase()
    {
        Database db = new Database(new List<int>() { 1 });

        db.Add(2);

        Assert.AreEqual(2, db.Count, ErrorMessageForDifferentCount, 2);
    }

    [Test]
    public void AddManyElementsToDatabase()
    {
        Database db = new Database(new List<int>() { 1 });

        db.Add(2);
        db.Add(2);
        db.Add(2);

        Assert.AreEqual(4, db.Count, ErrorMessageForDifferentCount, 4);
    }

    [Test]
    [TestCase(16)]
    public void AddMoreThanDatabaseCapacity(int count)
    {
        List<int> list = new List<int>();
        for (int i = 0; i < count; i++)
        {
            list.Add(i);
        }
        Database db = new Database(list);

        Assert.Throws<InvalidOperationException>(() => db.Add(3), "Cannot add more elements than max capacity");
    }

    [Test]
    public void CheckIfAddedElementIsLastInCollection()
    {
        Database db = new Database(new List<int>() { 1 });

        db.Add(2);

        CollectionAssert.AreEqual(new int[] { 1, 2 }, db.Elements);

    }

    [Test]
    public void CheckIfAddedElementsAreLastInCollection()
    {
        Database db = new Database(new List<int>() { 1 });

        db.Add(2);
        db.Add(3);
        db.Add(4);

        CollectionAssert.AreEqual(new int[] { 1, 2, 3, 4 }, db.Elements);
    }

    [Test]
    public void RemoveElementFromDatabase()
    {
        Database db = new Database(new List<int>() { 1, 2, 3 });

        db.Remove();

        CollectionAssert.AreEqual(new int[] { 1, 2 }, db.Elements);
    }

    [Test]
    public void RemoveManyElements()
    {
        Database db = new Database(new List<int>() { 1, 2, 3, 4, 5, 6 });

        db.Remove();
        db.Remove();
        db.Remove();

        CollectionAssert.AreEqual(new int[] { 1, 2, 3 }, db.Elements);
    }

    [Test]
    public void RemoveMoreElementsThanCollectionHave()
    {
        Database db = new Database(new List<int>() { 1, 2 });

        db.Remove();
        db.Remove();

        Assert.Throws<InvalidOperationException>(() => db.Remove());
    }
}

