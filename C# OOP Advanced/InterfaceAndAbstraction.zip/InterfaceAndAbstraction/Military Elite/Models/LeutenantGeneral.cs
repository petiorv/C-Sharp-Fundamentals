﻿using System;
using System.Collections.Generic;
using System.Text;
public class LeutenantGeneral : Private, ILeutenantGeneral
{
    public LeutenantGeneral(int id, string firstName, string lastName, double salary)
        : base(id, firstName, lastName, salary)
    {
        this.Privates = new List<IPrivate>();
    }

    public ICollection<IPrivate> Privates { get; set; }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("Privates:");
        foreach (Private privateSoldier in this.Privates)
        {
            sb.Append(privateSoldier.ToString());
            sb.AppendLine();
            
        }
        return (base.ToString() + Environment.NewLine + sb).Trim();

    }
}
