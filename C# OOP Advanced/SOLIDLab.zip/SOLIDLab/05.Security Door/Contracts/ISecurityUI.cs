﻿using _05.Security_Door.Contracts;
namespace _05.Security_Door
{
    public interface ISecurityUI : IPinCodeUI, IKeyCardUI
    {

    }
}