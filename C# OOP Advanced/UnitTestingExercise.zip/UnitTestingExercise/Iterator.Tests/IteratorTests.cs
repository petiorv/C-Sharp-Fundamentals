﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Tests
{
    [TestFixture]
    class IteratorTests
    {
        private string[] arr;
        private Iterator<string> iteratorList;

        [SetUp]
        public void SetUp()
        {
            this.arr = new string[] { "1", "2", "3", "4" };
            this.iteratorList = new Iterator<string>(this.arr);
        }

        [Test]
        public void ShouldThrowExceptionIfCtorIsWithNllValue()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                Iterator<string> i = new Iterator<string>(null);
            });
        }

        [Test]
        public void ThrowExceptionIfItemToPrintsIsEmpty()
        {
            string[] arr = new string[0];

            

            Assert.Throws<InvalidOperationException>(() =>
            {
                Iterator<string> i = new Iterator<string>(arr);
            });
        }
    }
}
