﻿public class Garage
{
}
