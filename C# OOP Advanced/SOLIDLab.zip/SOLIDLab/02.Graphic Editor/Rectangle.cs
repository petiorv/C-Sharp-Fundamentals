﻿namespace _02.Graphic_Editor
{
    public class Rectangle : IShape
    {
        public string Draw()
        {
            return "Rectangle";
        }
    }
}