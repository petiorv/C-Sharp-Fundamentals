﻿using System;
using System.Collections.Generic;
using System.Text;
public class Engineer : SpecialisedSoldier, IEngineer
{    

    public Engineer(int id, string firstName, string lastName, double salary, string corps)
        :base(id, firstName, lastName, salary, corps)
    {
        this.Repairs = new List<IRepair>();
    }

    public ICollection<IRepair> Repairs { get; set; }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(Environment.NewLine + "Repairs:");
        foreach (var rep in this.Repairs)
        {
            sb.AppendLine("  " + rep.ToString());
           
        }
        return base.ToString() + sb.ToString();
    }
}
