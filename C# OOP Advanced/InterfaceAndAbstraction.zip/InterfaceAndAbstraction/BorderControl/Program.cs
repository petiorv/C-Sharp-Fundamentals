﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    class Program
    {
        static void Main()
        {
            #region 05.BorderContorl
            //IList<IControlable> border = new List<IControlable>();

            //string input = Console.ReadLine();

            //while (input != "End")
            //{
            //    string[] args = input.Split(' ').ToArray();
            //    if (args.Length == 2)
            //    {
            //        IControlable robot = new Robot(args[0], args[1]);
            //        border.Add(robot);
            //    }
            //    else
            //    {
            //        IControlable citizen = new Citizen(args[0], int.Parse(args[1]), args[2]);
            //        border.Add(citizen);
            //    }
            //    input = Console.ReadLine();
            //}

            //string check = Console.ReadLine();

            //foreach (var item in border)
            //{
            //    if (item.Id.EndsWith(check))
            //    {
            //        Console.WriteLine(item.Id);
            //    }
            //}
            #endregion
            #region 06.Birthday Celebration
            //IList<IBirthable> border = new List<IBirthable>();

            //string input = Console.ReadLine();

            //while (input != "End")
            //{
            //    string[] args = input.Split(' ').ToArray();
            //    if (args[0] == "Citizen")
            //    {
            //        IBirthable citizen = new Citizen(args[1], int.Parse(args[2]), args[3], args[4]);
            //        border.Add(citizen);
            //    }
            //    if(args[0] == "Pet")
            //    {
            //        IBirthable pet = new Pet(args[1], args[2]);
            //        border.Add(pet);
            //    }
            //    input = Console.ReadLine();
            //}

            //string check = Console.ReadLine();
            //var result = border.Where(b => b.Birthdate.EndsWith(check));

            //foreach (var item in result)
            //{
            //    Console.WriteLine(item.Birthdate);
            //}

            #endregion
            #region 07.Food Shortage
            IDictionary<string, IBuyer> buyers = new Dictionary<string, IBuyer>();

            int cnt = int.Parse(Console.ReadLine());
            for (int i = 0; i < cnt; i++)
            {

                string[] args = Console.ReadLine().Split(' ').ToArray();
                if (args.Length == 3)
                {
                    IBuyer rebel = new Rebel(args[0], int.Parse(args[1]), args[2]);
                    buyers.Add(args[0], rebel);
                }
                else
                {
                    IBuyer citizen = new Citizen(args[0], int.Parse(args[1]), args[2], args[3]);
                    buyers.Add(args[0], citizen);
                }

            }

            string foodBuyer = Console.ReadLine();
            while (foodBuyer != "End")
            {
                if (buyers.ContainsKey(foodBuyer))
                {
                    buyers[foodBuyer].ByeFood();
                }

                foodBuyer = Console.ReadLine();
            }

            int totalFood = buyers.Sum(x => x.Value.Food);
            Console.WriteLine(totalFood);

            #endregion
        }
    }
}
