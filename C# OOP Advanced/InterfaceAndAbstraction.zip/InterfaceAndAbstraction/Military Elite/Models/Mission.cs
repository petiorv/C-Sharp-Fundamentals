﻿using System;
using System.Text;
public class Mission : IMission
{
    private string codeName;
    private string state;

    public Mission(string codeName, string state)
    {
        this.CodeName = codeName;
        this.State = state;
    }

    public string CodeName
    {
        get { return this.codeName; }
        private set { this.codeName = value; }
    }

    public string State
    {
        get { return this.state; }
        private set
        {
            if (value != "inProgress" && value != "Finished")
            {
                throw new ArgumentException("Invalid state!");
            }
            this.state = value;
        }
    }

    public void CompleteMission()
    {
        this.State = "Finished";
    }

    public override string ToString()
    {
        return string.Format("Code Name: {0} State: {1}", this.CodeName, this.State);
    }
}
