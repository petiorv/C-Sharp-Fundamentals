﻿public class Mood
{
    public string Name { get; set; }

    public Mood(string name)
    {
        this.Name = name;
    }
}

