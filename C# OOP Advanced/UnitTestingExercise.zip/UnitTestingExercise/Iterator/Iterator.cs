﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    public class Iterator<T>
    {
        private int currentIndex = 0;
        private T[] items;

        public Iterator(T[] items)
        {
            if (items == null)
            {
                throw new InvalidOperationException();
            }

            this.items = items;
        }

        public T Print()
        {
            if (this.items.Length == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            return this.items[currentIndex];
        }

        public bool HasNext()
        {
            return this.currentIndex + 1 < this.items.Length;
        }

        public bool Move()
        {
            if (this.currentIndex+1 < this.items.Length)
            {
                currentIndex++;
                return true;
            }
            return false;
        }

    }
}
