﻿using System;
public class Spy : Soldier, ISpy
{
    private int codeNumber;

    public Spy(int id, string firstName, string lastName, int codeNumber)
        :base(id, firstName, lastName)
    {
        this.CodeNumber = codeNumber;
    }

    public int CodeNumber
    {
        get { return this.codeNumber; }
        set { this.codeNumber = value; }
    }

    public override string ToString()
    {
        return base.ToString() + Environment.NewLine + string.Format("Code Number: {0}", this.CodeNumber);
    }
}
