﻿namespace _04.Recharge.Contracts
{
    public interface  IWorker
    {
        void Work(int hours);
    }
}
