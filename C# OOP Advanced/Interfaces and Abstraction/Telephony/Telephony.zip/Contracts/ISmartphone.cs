﻿public interface ISmartphone : IBrowsable, ICallable
{
}

