﻿using System;
using System.Reflection;
using System.Text;
using System.Linq;
public class Spy
{
    public string StealFieldInfo(string investigatedClass, params string[] requestedFields)
    {
        Type classType = Type.GetType(investigatedClass);
        FieldInfo[] classFields = classType.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
        StringBuilder sb = new StringBuilder();

        Object classInstance = Activator.CreateInstance(classType, new object[] { });

        sb.AppendLine("Class under investigation: " + investigatedClass);

        foreach (FieldInfo field in classFields.Where(f => requestedFields.Contains(f.Name)))
        {
            sb.AppendLine(field.Name + " = " + field.GetValue(classInstance));
        }

        return sb.ToString().Trim();
    }

    public string AnalyzeAcessModifiers(string investigatedClass)
    {
        Type classType = Type.GetType(investigatedClass);
        FieldInfo[] classFields = classType
            .GetFields(BindingFlags.Public
            | BindingFlags.Instance
            | BindingFlags.Static
            );

        MethodInfo[] classPublicMethods = classType
            .GetMethods(BindingFlags.Public | BindingFlags.Instance);

        MethodInfo[] classNonPublicMethods = classType
            .GetMethods(BindingFlags.NonPublic | BindingFlags.Instance);

        StringBuilder sb = new StringBuilder();

        foreach (FieldInfo field in classFields)
        {
            sb.AppendLine(field.Name + " must be private!");
        }
        foreach (MethodInfo nonPublicMethod in classNonPublicMethods.Where(m => m.Name.StartsWith("get")))
        {
            sb.AppendLine(nonPublicMethod.Name + " have to be public!");
        }
        foreach (MethodInfo publicMethod in classPublicMethods.Where(m => m.Name.StartsWith("set")))
        {
            sb.AppendLine(publicMethod.Name + " have to be private!");
        }
        return sb.ToString().Trim();
    }

    public string RevealPrivateMethods(string className)
    {
        StringBuilder sb = new StringBuilder();
        Type classType = Type.GetType(className);
        MethodInfo[] nonPublicMethods = classType.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance);
        sb.AppendLine("All Private Methods of Class: " + className);
        sb.AppendLine("Base Class: " + classType.BaseType.Name);

        foreach (MethodInfo nonPublicMethod in nonPublicMethods)
        {
            sb.AppendLine(nonPublicMethod.Name);
        }

        return sb.ToString().Trim();
    }

    public string CollectGettersAndSetters(string className)
    {
        StringBuilder sb = new StringBuilder();

        Type classType = Type.GetType(className);
        MethodInfo[] classMethods = classType.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

        MethodInfo[] getters = classMethods.Where(m => m.Name.StartsWith("get")).ToArray();
        foreach (MethodInfo method in getters)
        {
            sb.AppendLine(method.Name + " will return " + method.ReturnType);
        }

        MethodInfo[] setters = classMethods.Where(m => m.Name.StartsWith("set")).ToArray();
        foreach (MethodInfo method in setters)
        {
            sb.AppendLine(method.Name + " will set field of " + method.GetParameters().First().ParameterType);
        }
 
        return sb.ToString().Trim();
    }


}
