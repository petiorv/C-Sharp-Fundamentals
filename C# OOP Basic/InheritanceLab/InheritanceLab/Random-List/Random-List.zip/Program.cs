﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_List
{
    class Program
    {
        static void Main(string[] args)
        {
            RandomList rl = new RandomList();
            Console.WriteLine(rl.RandomString());
        }
    }
}
