﻿using NUnit.Framework;


[TestFixture]
public class HeroTests
{
    [Test]
    public void HeroGetsExpirienceAfterKillingTarget()
    {
        Hero hero = new Hero("Pesho",new Axe(10,10));
        Dummy dummy = new Dummy(20, 10);

        hero.Attack(dummy);

        Assert.AreEqual(10, hero.Experience);
    }
}
