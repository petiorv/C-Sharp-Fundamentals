﻿using System;
using System.Text.RegularExpressions;
public class Smartphone : ICallable, IBrowsable
{
    public void Browse(string url)
    {
        string pattern = @"[0-9]";
        Regex regex = new Regex(pattern);
        if (regex.IsMatch(url))
        {
            Console.WriteLine("Invalid URL!");
        }
        else
        {
            Console.WriteLine("Browsing: " + url + "!");
        }

    }

    public void Call(string number)
    {
        string pattern = @"\D";
        Regex regex = new Regex(pattern);
        if (regex.IsMatch(number))
        {
            Console.WriteLine("Invalid number!");
        }
        else
        {
            Console.WriteLine("Calling... " + number);
        }

    }
}
