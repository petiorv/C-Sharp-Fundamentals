﻿public class Felime : Mammal
{
    public Felime(string animalName, double animalWeight, string livingRegion)
        :base(animalName, animalWeight, livingRegion)
    {

    }
}

