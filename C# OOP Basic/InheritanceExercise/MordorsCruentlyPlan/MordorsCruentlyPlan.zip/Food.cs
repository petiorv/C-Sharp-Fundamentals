﻿public class Food
{
    public int Happines { get; set; }

    public Food(int happines)
    {
        this.Happines = happines;
    }
}
