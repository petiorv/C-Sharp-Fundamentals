﻿using System.Collections.Generic;
public interface SortStrategy
{
    void Sort(IList<object> list);
    //design pattern
}
