﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtendedDatabase.Tests
{
    [TestFixture]
    class ExtendedDatabaseTests
    {
        private ExtendedDatabase setUpDatabase;

        [SetUp]
        public void SetUp()
        {
            Person p1 = new Person(1, "Test1");
            Person p2 = new Person(2, "Test2");
            Person p3 = new Person(3, "Test3");
            this.setUpDatabase = new ExtendedDatabase(new List<Person>() { p1, p2, p3 });

        }

        [Test]
        public void ShoudInitialeDatabaseCorrectly()
        {
            Person[] persons = new Person[16];

            for (int i = 0; i < 16; i++)
            {
                persons[i] = new Person(i + 1, "Person" + i);
            }

            ExtendedDatabase db = new ExtendedDatabase(persons);

            Assert.AreEqual(persons.Length, db.Count);
        }

        [Test]
        public void ShouldThrowExceptionAfterAddingExistingUsername()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                this.setUpDatabase.Add(new Person(5, "Test1"));
            });
        }

        [Test]
        public void ShouldThrowExceptionAfterAddingExistingId()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                this.setUpDatabase.Add(new Person(1, "Test6"));
            });
        }

        [Test]
        public void FindByIdShouldThrowOperationExceptionIfIdIsZero()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                Person p = this.setUpDatabase.FindById(0);
            });
        }


        [Test]
        public void FindByNegativeIdShouldThrowExepction()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
            {
                Person p = this.setUpDatabase.FindById(-1);
            });
        }


        [Test]
        public void FindByIdWithValidIdShouldReturnPerson()
        {
            Person p = this.setUpDatabase.FindById(1);

            Assert.IsNotNull(p);
        }

        [Test]
        public void RemoveShouldRemoveLastAddedPerson()
        {
           Person p = (Person)this.setUpDatabase.Remove();

            Assert.AreEqual("Test3", p.Username);
            Assert.AreEqual(3, p.Id);

        }
    }
}
