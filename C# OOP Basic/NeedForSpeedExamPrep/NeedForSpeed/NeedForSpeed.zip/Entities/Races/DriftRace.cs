﻿public class DriftRace : Race
{
}
