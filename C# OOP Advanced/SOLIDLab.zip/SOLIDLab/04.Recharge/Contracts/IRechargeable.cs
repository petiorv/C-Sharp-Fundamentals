﻿namespace _04.Recharge
{
    public interface IRechargeable
    {
        void Recharge();
    }
}