﻿namespace _01HarestingFields
{
    using System;
    using System.Reflection;
    using System.Linq;
    class HarvestingFieldsTest
    {
        static void Main(string[] args)
        {
            //TODO put your reflection code here
            string className = "_01HarestingFields.HarvestingFields";
            Type classType = Type.GetType(className);
            FieldInfo[] classFields = classType.GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance | BindingFlags.FlattenHierarchy);
            string input = Console.ReadLine();

            while (input != "HARVEST")
            {
                switch (input)
                {
                    case "private": GetFields(classFields.Where(f => f.IsPrivate).ToArray());
                        break;
                    case "public": GetFields(classFields.Where(f => f.IsPublic).ToArray());
                        break;
                    case "protected": GetFields(classFields.Where(f => f.IsFamily).ToArray());
                        break;
                    case "all": GetFields(classFields);
                        break;
                    default:
                        break;
                }
                input = Console.ReadLine();
            }
            
            

           

        }

        public static void GetFields(FieldInfo[] classFields)
        {
            foreach (FieldInfo field in classFields)
            {

                if (field.IsFamily)
                {
                    Console.Write(AccessModifier.Protected.ToString().ToLower() + " ");
                }
                if (field.IsPrivate)
                {
                    Console.Write(AccessModifier.Private.ToString().ToLower() + " ");
                }
                if (field.IsPublic)
                {
                    Console.Write(AccessModifier.Public.ToString().ToLower() + " ");
                }
                if (field.IsAssembly)
                {
                    Console.Write(AccessModifier.Internel.ToString().ToLower() + " ");
                }
                Console.WriteLine(field.FieldType.Name + " " + field.Name);
            }
        }
    }
}
