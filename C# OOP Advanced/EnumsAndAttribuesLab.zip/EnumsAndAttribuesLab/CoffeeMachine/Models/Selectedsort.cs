﻿using System.Collections.Generic;
public class Selectedsort : SortStrategy
{

    public void Sort(IList<object> list)
    {
        throw new System.NotImplementedException();
    }
}
