﻿using NUnit.Framework;


[TestFixture]
public class DummyTests
{
    [Test]
    public void DummyLoseHealthIfAttack()
    {
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(20, 20);

        dummy.TakeAttack(axe.AttackPoints);

        Assert.AreEqual(10, dummy.Health);
    }
}
