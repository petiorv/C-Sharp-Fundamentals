﻿public enum AccessModifier
{
    Private, 
    Protected,
    Internel,
    Public
}

