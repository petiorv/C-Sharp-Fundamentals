﻿using System;
using System.Collections.Generic;
using System.Text;
public class Commando : SpecialisedSoldier, ICommando
{
    
    public Commando(int id, string firstName, string lastName, double salary, string corps)
        :base(id, firstName, lastName, salary, corps)
    {
        this.Missions = new List<IMission>();
    }

    public ICollection<IMission> Missions { get; private set; }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        foreach (var mission in Missions)
        {
            sb.AppendLine(mission.ToString());
        }

        return base.ToString() + Environment.NewLine + "Missions:" + Environment.NewLine + sb.ToString();
    }
}

