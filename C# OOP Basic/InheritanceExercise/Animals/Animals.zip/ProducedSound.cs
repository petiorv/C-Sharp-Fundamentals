﻿public abstract class ProducedSound
{
    public virtual string ProduceSound()
    {
        return this.ToString();
    }
}
