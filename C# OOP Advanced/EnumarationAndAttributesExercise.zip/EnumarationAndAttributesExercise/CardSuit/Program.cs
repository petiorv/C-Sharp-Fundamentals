﻿using System;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        #region 1-4
        //var rank = Console.ReadLine();
        //var suit = Console.ReadLine();

        //Card card = new Card(rank, suit);

        //Console.WriteLine(card);

        #endregion

        #region 05.Card CompareTo

        //var c1rank = Console.ReadLine();
        //var c1suit = Console.ReadLine();

        //var c2rank = Console.ReadLine();
        //var c2suit = Console.ReadLine();

        //Card firstCard = new Card(c1rank, c1suit);
        //Card secondCard = new Card(c2rank, c2suit);

        //if (firstCard.CompareTo(secondCard) > 0)
        //{
        //    Console.WriteLine(firstCard);
        //}
        //else
        //{
        //    Console.WriteLine(secondCard);
        //}
        #endregion

        #region 06 Custom Attribute

        string inputCategory = Console.ReadLine();

        var customAttributes = typeof(CardRank).GetCustomAttributes(false)
            .Union(typeof(CardSuit).GetCustomAttributes(false))
            .Where(ca => ca.GetType() == typeof(TypeAttribute));

        foreach (TypeAttribute customAttribute in customAttributes)
        {
            if (customAttribute.Category == inputCategory)
            {
                Console.WriteLine(customAttribute);
                break;
            }
        }
        

        #endregion
    }
}

