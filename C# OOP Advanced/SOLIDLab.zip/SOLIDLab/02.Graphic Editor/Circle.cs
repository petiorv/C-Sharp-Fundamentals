﻿namespace _02.Graphic_Editor
{
    public class Circle : IShape
    {
        public string Draw()
        {
            return "Circle";
        }
    }
}