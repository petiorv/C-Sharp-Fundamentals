﻿public interface IControlable
{
    string Id { get; }
}
