﻿public class CasualRace : Race
{
}
