﻿using System;
public class Card : IComparable<Card>
{
    public Card(string rank, string suit)
    {
        CardRank cardRank;
        CardSuit cardSuit;
        
        if (Enum.TryParse(rank, out cardRank) && Enum.TryParse(suit, out cardSuit))
        {
            this.Rank = rank;
            this.Suit = suit;
            this.Power = (int)cardSuit + (int)cardRank;
        }
    }

    public string Rank { get; private set; }
    public string Suit { get; private set; }
    public int Power { get;  private set; }
   

    public void GetCardsSuit()
    {
        Type cardSuitType = typeof(CardSuit);
        var cardSuitNames = Enum.GetNames(cardSuitType);
        Console.WriteLine("Card Suits:");
        foreach (var cardSuit in cardSuitNames)
        {
            CardSuit card;
            if (Enum.TryParse(cardSuit, out card))
            {
                Console.WriteLine("Ordinal value: " + (int)card + "; Name value: " + cardSuit);
            }

        }
    }

    public void GetCardRank()
    {
        Type cardRankType = typeof(CardRank);
        var cardRankNames = Enum.GetNames(cardRankType);
        Console.WriteLine("Card Ranks:");
        foreach (var rank in cardRankNames)
        {
            CardRank cardRank;
            if (Enum.TryParse(rank, out cardRank))
            {
                Console.WriteLine("Ordinal value: " + (int)cardRank + "; Name value: " + rank);
            }
        }
    }

    public override string ToString()
    {        
        return "Card name: " + this.Rank + " of " + this.Suit + "; Card power: " + this.Power;
    }

    public int CompareTo(Card other)
    {
        return this.Power.CompareTo(other.Power);
    }
}

