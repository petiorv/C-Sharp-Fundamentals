﻿using System.Collections.Generic;
public class QuickSort : SortStrategy
{
    public void Sort(IList<object> list)
    {
    }
}

