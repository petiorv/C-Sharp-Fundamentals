﻿using System.Collections.Generic;
class MergeSort : SortStrategy
{
    public void Sort(IList<object> list)
    {
        throw new System.NotImplementedException();
    }
}
