﻿public interface ICar
{
    string Brakes();
    string GasPedal();
}
