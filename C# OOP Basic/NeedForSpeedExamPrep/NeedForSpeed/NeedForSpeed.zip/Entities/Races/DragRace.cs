﻿public class DragRace : Race
{
}
