﻿namespace _04.Recharge
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
