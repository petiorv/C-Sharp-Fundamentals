﻿using System.Collections.Generic;
public class SortedList
{
    private List<object> list;

    public void Sort(SortStrategy startegy)
    {

    }
}
