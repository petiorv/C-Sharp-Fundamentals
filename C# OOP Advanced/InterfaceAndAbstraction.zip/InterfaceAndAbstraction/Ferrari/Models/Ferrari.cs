﻿class Ferrari : ICar
{
    private const string model = "488-Spider";
    private string driver;

    public Ferrari(string name)
    {
        this.Driver = name;
    }
    public string Model
    {
        get { return model; }
    }

    public string Brakes()
    {
        return "Brakes!";
    }

    public string GasPedal()
    {
        return "Zadu6avam sA!";
    }

    public string Driver
    {
        get { return this.driver; }
        set { this.driver = value; }
    }

    public override string ToString()
    {
        return this.Model + "/" + this.Brakes() + "/" + this.GasPedal() + "/" + this.Driver;
    }
}

