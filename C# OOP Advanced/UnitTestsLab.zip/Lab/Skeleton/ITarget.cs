﻿public interface ITarget
{
    int Health { get; }
    void TakeAttack(int attackPoints);
    int GiveExpirience();
    bool IsDead();
}
